# -*- coding: utf-8 -*-
"""S60 Wiki"""

import os.path
import os
import re
import shutil
import sys
import time

import key_codes
import appuifw
import e32

DIRECTORY_PATH = "e:/fubuki"
LOGFILE = "fubukilog"


def main():
    logfile = file(os.path.join(DIRECTORY_PATH, LOGFILE), "w")
    sys.stderr = sys.stdout = logfile
    app = Application()
    app.mainloop()
    logfile.close()
    del app


class Application:
    def __init__(self):
        self.view = View(self)
        self.page = None
        self.history = []
        self.openPage("FrontPage")
        self.lock=e32.Ao_lock()

    def mainloop(self):
        self.lock.wait()
        del self.view
        del self.page

    def openPage(self, pagename):
        if self.page:
            self.savePage()
        self.page = Page(pagename)
        self.view.setPage(self.page)

    def openNewPage(self, pagename):
        self.history.append(self.page.name)
        self.openPage(pagename)

    def back(self):
        if len(self.history) > 0:
            pagefile = self.history.pop()
            self.openPage(pagefile)

    def savePage(self):
        newContent = self.view.latestPageContent()
        oldContent = self.page.text()
        if newContent != oldContent:
            self.page.text(newContent)

    def openLink(self, text, position):
        pagename = self.extractPagename(text, position)
        if pagename:
            self.openNewPage(pagename)

    def openFrontPage(self):
        self.openNewPage("FrontPage")


    def extractPagename(self, text, here):
        """return link string at current position"""
        pattern = re.compile(u"\[[^\[]*$")

        m = pattern.search(text, 0, here+1)
        if m == None: 
            return None
        left = m.start()

        pattern = re.compile(u"[^\]]+\]")
        m = pattern.search(text, max(here-1,0))
        if m == None:
            return None
        right = m.end()

        if left <= here and here <= right:
            return text[left+1:right-1]
        else:
            return None

    def exit(self):
        try:
            self.savePage()
        finally:
            self.lock.signal()


class View:
    def __init__(self, app):
        self.app = app
        self.textControl = appuifw.Text()
        self.page = None
        self.positionInPage = {}
        appuifw.app.body = self.textControl
        appuifw.app.menu=[(u"Back", self.app.back),
                          (u"Jump", self.openLink),
                          (u"Find", self.findText),
                          (u"Insert []", self.insertLink),
                          (u"List all pages", self.listPages),
                          (u"FrontPage", self.app.openFrontPage),
                          (u"Exit", self.app.exit)]
        appuifw.app.exit_key_handler = self.app.exit
        self.textControl.bind(key_codes.EKeySelect, self.openLink)
        self.textControl.bind(key_codes.EKeyDownArrow, self.nextLine)
        self._stringToSearch = u""

    def nextLine(self):
        """add a new line if the cursor position is at the end"""
        if self.textControl.len() == self.textControl.get_pos():
            self.textControl.add(u"\n")

    def setPage(self, page):
        self.page = page
        self.text(self.page.text())
        self.title(self.page.name)
        self.position(self.positionInPage.get(self.page.name, 0))

    def latestPageContent(self):
        return self.text()

    def text(self, string=None):
        """set or get text content"""
        if string is None:
            return self.textControl.get()
        else:
            self.textControl.set(string)
            self.textControl.set_pos(0)

    def position(self, value=None):
        if value is None:
            return self.textControl.get_pos()
        else:
            self.textControl.set_pos(value)

    def title(self, ustring):
        appuifw.app.title = u"" + ustring

    def listPages(self):
        pagenames = [x.decode('utf-8') for x in os.listdir(DIRECTORY_PATH)]
        try:  
            pagenames.remove(LOGFILE)
        finally:
            index = appuifw.selection_list(choices=pagenames , search_field=1)
            self.app.openNewPage(pagenames[index])

    def openLink(self):
        appuifw.note(u"Jumping...")  # this delay prevents wiki from crashing
        self.positionInPage[self.page.name] = self.position()
        self.app.openLink(self.text(), self.position())

    def findText(self):
        s = appuifw.query(u"Find", "text", self._stringToSearch)
        if s:
           p = self.textControl.get_pos()
           t = self.textControl.get(p)
           start = t.find(s)
           if start>0:
             self.textControl.set_pos(start+p)
           else:
             appuifw.note(u"not found")
           self._stringToSearch = s
        pass

    def insertLink(self):
        self.textControl.add(u"[]")
        self.textControl.set_pos(self.textControl.get_pos()-1)


class Page:
    def __init__(self, name):
        self.name = name

    def text(self, string=None):
        """set or get text content of page"""
        p = os.path.join(DIRECTORY_PATH, self.name.encode('utf8'))
        if string is None:
            if not os.path.exists(p):
                file(p,"w").write('')
            return unicode(file(p).read(), 'utf8', 'replace')
        else:
            tmp = p + ".tmp"
            string = string.replace(u"\u2029", u"\r\n")
            file(tmp, "w").write(string.encode('utf8', 'replace'))
            shutil.copyfile(tmp, p)
            os.remove(tmp)


if __name__ == "__main__":
    main()

